import 'dart:developer';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqliteflutter/QuotesDataModel.dart';

class Dbhelper {
  Future initDb() async {
    final dbpath = await getDatabasesPath();
    final path = join(dbpath, "quotes.db");

    final exist = await databaseExists(path);

    if (exist) {
      // print("DB Already exists");
    } else {
      // print("creating copy from assets");

      try {
        await Directory(dirname(path)).create(recursive: true);
      } catch (_) {}

      ByteData data = await rootBundle.load(join("assets", "quotes.db"));
      List<int> bytes =
          data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);

      await File(path).writeAsBytes(bytes, flush: true);

      // print("DB copied");
    }
    try {
      return await openDatabase(path);
      // log("openDatabase err $e");
    } catch (e) {
      log("openDatabase err $e");
    }
  }

  // Future retrieveQuotes() async {
  //   final Database db = await initDb();
  //

  //
  //   // Convert the List<Map<String, dynamic> into a List<Dog>.
  //   // return List.generate(maps.length, (i) {
  //   //   return Quotes(
  //   //     id: maps[i]['id'],
  //   //     quotes: maps[i]['quotes'],
  //   //     favourites: maps[i]['favourites'],
  //   //   );
  //   // });
  // }

  Future<List<Quotes>> getQuotes() async {
    final Database db = await initDb();
    List<Map> list = await db.rawQuery('SELECT * FROM quotes');
    List<Quotes> quotes = [];
    // try {
    //   print("quotes data: $list");
    // } catch (e) {
    //   print("err $e");
    // }
    for (int i = 0; i < list.length; i++) {
      quotes.add(Quotes(
          id: list[i]["id"],
          quotes: list[i]["quotes"],
          favourites: list[i]["favourites"],
          lock: list[i]["lock"]));
    }
    return quotes;
  }

  Future<List<Quotes>> getFavQuotes() async {
    final Database db = await initDb();
    List<Map> list =
        await db.rawQuery('SELECT * FROM quotes WHERE favourites = 1');
    List<Quotes> quotes = [];
    for (int i = 0; i < list.length; i++) {
      quotes.add(Quotes(
          id: list[i]["id"],
          quotes: list[i]["quotes"],
          favourites: list[i]["favourites"],
          lock: list[i]["lock"]));
    }
    return quotes;
  }

  Future<void> updateFav(int fav, int id) async {
    final Database db = await initDb();
    await db.rawQuery('UPDATE quotes SET favourites = $fav WHERE id = $id');
  }

  Future<void> updateLock(int lock, int id) async {
    final Database db = await initDb();
    await db.rawQuery('UPDATE quotes SET lock = $lock WHERE id = $id');
  }

  Future<void> addQuote(String quote) async {
    final Database db = await initDb();
    await db.rawInsert(
        'INSERT INTO quotes(quotes,favourites) VALUES(?,?)', [quote, 0]);
  }

  Future<void> deleteQuote(int id) async {
    final Database db = await initDb();
    await db.rawDelete('DELETE FROM quotes WHERE ID = $id');
  }
}
